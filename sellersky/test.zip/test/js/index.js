(function(){
    initUserList();

})();

/**
 * 初始化用户列表
 */
function initUserList(){
    var user_table = $("#grid").find(".table-body");
    $("#grid").find(".table-body").html("");

  /*伪造数据↓。用于测试，接口写好之后可直接删除*/
    var user_arr = [];
    for(var i = 0; i<=3; i++){
        var user_obj = {
            user_num:i,
            user_name:"hahah"+i,
            user_remark:"是好人" +i,
            user_status:"封存",
            create_date:"2015-12-"+i,
            late_date:"2016-02-"+i,
            user_type:2
        };
        user_arr.push(user_obj);
    }

    $.each(user_arr,function (indes,value) {
        var tr = "";
        tr += '<tr><td class="user-num">'+ value.user_num +'</td>'+
            '<td><input type="text" class="user-info-input user-name" value="'+ value.user_name+'" /></td>'+
            '<td><input type="text" class="user-info-input user-remark" value="'+ value.user_remark+'" /></td>';

        tr +=  '<td><label class="user-status">' +
            '<label><input type="radio" name="user-status_'+indes+'" class="user-info-input " value="封存" />封存</label>'+
            '<label><input type="radio" name="user-status_'+indes+'" class="user-info-input " value="启封" />启封</label>'+
            '</label></td>';

        tr += '<td>'+value.create_date+'</td>'+
            '<td>'+value.late_date+'</td>';
        tr += '<td>' +
            ' <select class="select_gallery user-type user-info-input" >'+
            '<optgroup label="角色">'+
            '<option value="1" selected = "selected">超级用户</option>'+
            '<option value="2">一般用户</option>'+
            '</optgroup>'+
            '</select>' +
            '</td>';
        tr += '<td>' +
            '<a class="icon-btn icon-edit" title="修改" onclick="changeInfo(this)"></a>'+

            '<a class="icon-trash icon-btn" title="删除" onclick="deleteUser(this)"></a>' +
            '</td>' +
            '</tr>';

        user_table.append(tr);

        $(".user-status").eq(indes).find("input[value='"+value.user_status+"']").prop("checked","checked");
        $(".user-type").eq(indes).find("option[value='"+value.user_type+"']").prop("selected","selected");
        $(".user-info-input").prop("disabled","disabled");
    });
/*伪造数据↑*/


    $.ajax({
        url:"",/*接口地址----------------------------------------------------------*/
        type:"POST",
        dataType:"json",

        success:function(e,data){
            var user_arr =  data.user_arr;//后台传过来数据，是一个对象数组。对象结构以及属性名称参考伪造数据中的对象结构

            $.each(user_arr,function (indes,value) {
                var tr = "";
                tr += '<tr><td class="user-num">'+ value.user_num +'</td>'+
                    '<td><input type="text" class="user-info-input user-name" value="'+ value.user_name+'" /></td>'+
                    '<td><input type="text" class="user-info-input user-remark" value="'+ value.user_remark+'" /></td>';

                tr +=  '<td><label class="user-status">' +
                    '<label><input type="radio" name="user-status_'+indes+'" class="user-info-input " value="封存" />封存</label>'+
                    '<label><input type="radio" name="user-status_'+indes+'" class="user-info-input " value="启封" />启封</label>'+
                    '</label></td>';

                tr += '<td>'+value.create_date+'</td>'+
                    '<td>'+value.late_date+'</td>';
                tr += '<td>' +
                    ' <select class="select_gallery user-type user-info-input" >'+
                    '<optgroup label="角色">'+
                    '<option value="1" selected = "selected">超级用户</option>'+
                    '<option value="2">一般用户</option>'+
                    '</optgroup>'+
                    '</select>' +
                    '</td>';
                tr += '<td>' +
                    '<a class="icon-btn icon-edit" title="修改" onclick="changeInfo(this)"></a>'+

                    '<a class="icon-trash icon-btn" title="删除" onclick="deleteUser(this)"></a>' +
                    '</td>' +
                    '</tr>';

                user_table.append(tr);

                $(".user-status").eq(indes).find("input[value='"+value.user_status+"']").prop("checked","checked");
                $(".user-type").eq(indes).find("option[value='"+value.user_type+"']").prop("selected","selected");

            });
            $(".user-info-input").prop("disabled","disabled");
        },
        error: function (e) {
//            alert("数据请求失败！");
        }
    })
}

/**
 * 修改用户信息
 * @param this_
 */
function changeInfo(this_) {
    var input_arr = $(this_).parents("tr").find("input[type = 'text']").not(".date-picker");
    input_arr.toggleClass("input-is-show");

    if($(this_).attr("class").indexOf("icon-edit") >= 0){
        input_arr.removeAttr("disabled");
        $(this_).parents("tr").find("input[type = 'radio']").removeAttr("disabled");
        $(this_).parents("tr").find("select").removeAttr("disabled");
    }else{
        var name = $(this_).parents("tr").find(".user-name").val();
        var remark = $(this_).parents("tr").find(".user-remark").val();
        var status = $(this_).parents("tr").find('input:radio:checked').val();
        var account_type = $(this_).parents("tr").find("select").val();
        $.ajax({
            url:"",/*修改用户的接口。传给后台的数据以及属性名称参考以下data的数据，没有传递创建时间和最后登录时间 ------------------*/
            type:"POST",
            dataType:"json",
            data:{
              "name":name,
                "remark":remark,
                "status":status,
                "account_num":account_type
            },
            success:function(e,data){

                alert("修改成功");
                initUserList();

            },
            error: function (e) {
//                alert("数据请求失败！");
            }
        })
    }

    $(this_).toggleClass("icon-file icon-edit");

}

/**
 * 删除用户
 * @param this_
 */
function deleteUser(this_){
    var user_num = $(this_).parents("tr").find(".user-num").text();
    $.ajax({
        url: "",/*删除用户的url。传递给后台的数据是用户的编号-----------------------------------------------*/
        type: "POST",
        dataType: "json",
        data: {
            "user_num": user_num
        },
        success: function (e, data) {
            alert("删除成功！");
            initUserList();
        },
        error: function (e) {
//            alert("数据请求失败！");
        }
    })
}

/**
 * 新建用户信息
 */
function saveUserInfo(){
    var name = $(".user-name").val();
    var remark = $(".user-remark").val();
    var status = $('input:radio[name="user-status"]:checked').val();
    var account_num = $('.select_gallery').val();

    $.ajax({
        url: "",/*新建用户的接口，传递给后台的如data中的数据，编号应该由后台生成，（唯一标识）-------------------------*/
        type: "POST",
        dataType: "json",
        data: {
            "name": name,
            "remark": remark,
            "status": status,
            "account_num": account_num
        },
        success: function (e, data) {
            alert("新建成功！");
            initUserList();
        },
        error: function (e) {
//            alert("数据请求失败！");
        }

    })
}