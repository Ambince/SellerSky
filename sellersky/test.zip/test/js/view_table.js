// JavaScript Document

$(function(){
            $('#grid').dataTable();
            });
        $(document).ready(function(e) {
            
            $('th').hover(function(){
            $(this).addClass('hover');},
            function(){
                $(this).removeClass('hover');
                })
			$(".delectfun").click(function(){
				alert("是否确定要删除？");
				})
			
        })